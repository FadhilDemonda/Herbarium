---
name: Superset Query Library
colors:
  surface: '#fdf9ed'
  surface-dim: '#dddace'
  surface-bright: '#fdf9ed'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3e7'
  surface-container: '#f2eee1'
  surface-container-high: '#ece8dc'
  surface-container-highest: '#e6e2d6'
  on-surface: '#1c1c15'
  on-surface-variant: '#414942'
  inverse-surface: '#323129'
  inverse-on-surface: '#f5f1e4'
  outline: '#717972'
  outline-variant: '#c1c9c0'
  surface-tint: '#3c674c'
  primary: '#275338'
  on-primary: '#ffffff'
  primary-container: '#3f6b4f'
  on-primary-container: '#b9eac6'
  inverse-primary: '#a2d2b0'
  secondary: '#904b2e'
  on-secondary: '#ffffff'
  secondary-container: '#ffa581'
  on-secondary-container: '#78391d'
  tertiary: '#862b19'
  on-tertiary: '#ffffff'
  tertiary-container: '#a6422e'
  on-tertiary-container: '#ffd5cc'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bdeecb'
  primary-fixed-dim: '#a2d2b0'
  on-primary-fixed: '#002110'
  on-primary-fixed-variant: '#234f35'
  secondary-fixed: '#ffdbce'
  secondary-fixed-dim: '#ffb598'
  on-secondary-fixed: '#370e00'
  on-secondary-fixed-variant: '#733519'
  tertiary-fixed: '#ffdad3'
  tertiary-fixed-dim: '#ffb4a5'
  on-tertiary-fixed: '#3e0400'
  on-tertiary-fixed-variant: '#822716'
  background: '#fdf9ed'
  on-background: '#1c1c15'
  surface-variant: '#e6e2d6'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.005em
  code-lg:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.005em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-compact: 0.5rem
  margin: 2rem
  margin-compact: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system conveys an intentional, intellectual calm reminiscent of an architect’s notebook resting on a solid timber workbench. Designed for data engineers, SQL analysts, and technical leads navigating complex datasets, it transforms analytical query management from an abrasive, high-stress cockpit into a focused, contemplative studio.

The visual style blends warm organic minimalism with tactile desktop precision:
- **Atmosphere:** Natural, quiet, grounded, and orderly. Tactile paper hues replace sterile cold whites.
- **Form Factor Focus:** Desktop-first productivity suite built for information density, side-by-side SQL exploration, and clear spatial hierarchy.
- **Aesthetic Direction:** Warm editorial realism featuring delicate 1px borders, subtle warm-tinted floating shadows, ample breathing room, and meticulous monospaced typography for query authoring.

## Colors

The palette balances earthy forest tones and warm natural substrates, eliminating harsh clinical spectrums while maintaining strict WCAG AAA legibility for code blocks and metadata.

### Light Mode (Notebook Canvas)
- **Primary (`#3F6B4F`):** Deep Forest Pine. Used for active navigation tabs, primary execution CTAs, key schema markers, and validated query status badges.
- **Secondary (`#B86B4B`):** Warm Terracotta. Used for query parameters, bookmarks, secondary callouts, tags, and run history states.
- **Destructive (`#A8432F`):** Muted Brick Red. Used exclusively for drop statements, deletions, query syntax errors, and connection termination warnings.
- **Neutral Surface Canvas (`#F7F5EF`):** Warm Cream substrate replicating heavy acid-free notebook paper.
- **Neutral Elevated Container (`#FFFFFF`):** Pure warm card surface for SQL editor viewports and data table modules.
- **Borders & Rules (`#E6E1D6`):** Soft parchment linework providing structural separation without visual noise.
- **Text Primary (`#252422`):** Deep carbon black for maximum contrast and low eye fatigue.
- **Text Secondary (`#6E6B64`):** Earthy slate for line numbers, timestamps, and schema meta.

### Dark Mode (Dark Forestry)
- **Canvas Base (`#161B17`):** Moss charcoal background.
- **Surface Elevation (`#1E2520`):** Muted pine slate for active editor panes and inspection drawers.
- **Borders & Rules (`#2D3830`):** Subdued forest edge linework.
- **Primary Brightened (`#5D9470`):** Luminescent spruce for interactions and execution state.
- **Secondary Accent (`#D08362`):** Warm clay amber for alerts and syntax keys.
- **Destructive Brightened (`#C95A44`):** Softened rust for syntax failures and query cancels.
- **Text Primary (`#E8ECE9`):** Soft birch white.

## Typography

The type scale orchestrates a split between warm human clarity (**Plus Jakarta Sans**) and mechanical precision (**JetBrains Mono**):

- **Interface & Prose:** Plus Jakarta Sans provides friendly, organic geometric shapes with open counters, preventing eye strain during multi-hour research and catalog auditing.
- **SQL & Technical Metadata:** JetBrains Mono is assigned to all query workspaces, execution metrics, row counts, parameters, and variable inputs. Ligatures are enabled for SQL operators (`!=`, `>=`, `->`).
- **Rhythm & Alignment:** Monospace fonts use strict `20px` or `24px` line heights to ensure precise visual pairing with gutter line-number counts and split-pane diff comparisons.

## Layout & Spacing

The workspace uses a multi-pane flexible split grid inspired by technical drafting stations:
- **Spatial Strategy:** A fixed collapsible left rail (260px) for schema and folder navigation, an elastic central canvas for the query buffer, and a contextual collapsible inspector drawer (320px) on the right for run lineage and parameter sets.
- **Canvas Margins:** Wide `2rem` outer padding on the outer framing mimics notebook margins, while inner IDE toolbars tighten to `0.5rem` to optimize data density.
- **Grid Structure:** Analytical output tables and query catalog lists use a 12-column variable flex grid, with `1rem` column gutters ensuring distinct demarcation of parameters and execution telemetry.

## Elevation & Depth

Visual hierarchy abandons steep digital drops in favor of architectural, warm-tinted paper overlays:

- **Surface Tiers:**
  - *Tier 0 (Desk Substrate):* Warm canvas (`#F7F5EF` / `#161B17`), flat without elevation.
  - *Tier 1 (Notebook Sheet):* Active query cards and SQL editor work surface (`#FFFFFF` / `#1E2520`), framed by a crisp 1px border (`#E6E1D6` / `#2D3830`) and an ambient warm lift: `box-shadow: 0 2px 8px -2px rgba(60, 52, 42, 0.04), 0 1px 2px -1px rgba(60, 52, 42, 0.03)`.
  - *Tier 2 (Floating Palette & Popovers):* Autocomplete boxes, command palettes, schema inspectors, and context menus: `box-shadow: 0 10px 24px -4px rgba(45, 38, 30, 0.08), 0 4px 8px -2px rgba(45, 38, 30, 0.04)`.
- **Border Treatment:** All surface transitions strictly implement a 1px border tinted in tonal neutral sand (`#E6E1D6`) in light mode and deep forest spruce (`#2D3830`) in dark mode, maintaining structure even under low-contrast monitor calibrations.

## Shapes

The design system maintains a balanced, refined radius scale (`roundedness: 1`):
- **Base Components:** Inputs, execution buttons, metadata tags, line counters, and status badges use `0.25rem` (4px) corner radiuses.
- **Cards & Panes:** Code editor containers, SQL results tables, and query snippet blocks use `rounded-lg` (`0.5rem` / 8px).
- **Modals & Overlays:** The master query runner palette and schema viewer use `rounded-xl` (`0.75rem` / 12px).
- **Philosophy:** Rounded forms remain subtle and understated, echoing trimmed card stock rather than playful pill geometries.

## Components

### Buttons
- **Primary ("Run Query"):** Filled Forest Green (`#3F6B4F`), pure white Plus Jakarta Sans text (weight 600), 1px border (`#345942`). Subtle hover shifts to `#365D44` with a warm 2px focus ring (`#3F6B4F33`).
- **Secondary ("Save Snippet" / "Fork"):** Warm cream background, Terracotta text (`#B86B4B`), border 1px solid `#E6E1D6`. Hover background transitions to `#EDE9DE`.
- **Destructive ("Drop View"):** Outlined Brick Red (`#A8432F`), faint tint background (`#A8432F0D`), sharp 1px border.

### SQL Code Editor & Cells
- **Editor Frame:** Elevated Tier 1 card with a persistent 1px border. Gutter displays JetBrains Mono line numbers in muted `#9E9A90`.
- **Syntax Highlighting (Notebook Harmony):**
  - Keywords (`SELECT`, `JOIN`, `GROUP BY`): Forest Green (`#3F6B4F`), bold.
  - String Literals: Terracotta (`#B86B4B`).
  - Functions & Aggregates: Earth Amber (`#945D36`).
  - Comments: Italicized Pale Timber (`#8C887E`).
- **Selection State:** Translucent warm moss highlight (`rgba(63, 107, 79, 0.12)`).

### Chips & Badges
- **Query Status Chips:** Pill-soft 4px radius, JetBrains Mono `11px`.
  - *Success / Cached:* Forest Green text on `#3F6B4F14` tint.
  - *Draft / Parameterized:* Terracotta text on `#B86B4B14` tint.
  - *Failed / Syntax Error:* Brick Red text on `#A8432F14` tint.

### Data Tables (Query Results)
- **Header:** Plus Jakarta Sans uppercase `label-md`, background `#EFECE3`, border-bottom 1px solid `#DCD6C8`.
- **Data Cells:** JetBrains Mono `13px`, compact vertical padding (`space-xs` to `space-sm`), subtle horizontal dividing line (`#F0ECE4`). Striped rows use alternating `#FAF9F5`.

### Input Fields & Filter Bars
- Monospaced inputs for parameters; natural Plus Jakarta Sans for catalog search. Thin 1px `#DCD6C8` border, default background `#FFFFFF`. Active focus changes border color to `#3F6B4F` with zero blur displacement.